﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ClassAsg_W15_Edward_Geraldo
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand = new MySqlCommand();
        MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter();
        string sqlQuery;
        string sqlQuery2;
        string sqlQuery3;
        string sqlQuery4;

        DataTable dtHome;
        DataTable dtAway;
        DataTable dtManager;
        DataTable dtCaptain;
        DataTable dtMatch;
        DataTable dtDGV;
       
        int indexRow;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server = localhost; uid = student; pwd = isbmantap; database = premier_league;");
            sqlQuery = "select * from team";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dtHome = new DataTable();
            dtAway = new DataTable();
            sqlDataAdapter.Fill(dtHome);
            sqlDataAdapter.Fill(dtAway);

            cbox_home.DataSource = dtHome;
            cbox_home.DisplayMember = "team_name";
            cbox_home.ValueMember = "team_id";

            cbox_away.DataSource = dtAway;
            cbox_away.DisplayMember = "team_name";
            cbox_away.ValueMember = "team_id";

            sqlQuery2 = "select * from manager";
            sqlCommand = new MySqlCommand(sqlQuery2, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dtManager = new DataTable();
            sqlDataAdapter.Fill(dtManager);

            sqlQuery3 = "select * from player";
            sqlCommand = new MySqlCommand(sqlQuery3, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dtCaptain = new DataTable();
            sqlDataAdapter.Fill(dtCaptain);

            sqlQuery4 = "select * from `match`";
            sqlCommand = new MySqlCommand(sqlQuery4, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dtMatch = new DataTable();
            sqlDataAdapter.Fill(dtMatch);

            cbox_home.SelectedIndex = -1;
            cbox_away.SelectedIndex = -1;

            
        }

        private void cbox_home_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cbox_home.SelectedIndex == -1 || cbox_away.SelectedIndex == -1)
            {

            }
            else
            {
                if (cbox_home.SelectedIndex == cbox_away.SelectedIndex)
                {
                    MessageBox.Show("Same Team");
                }
                else
                {

                    DataTable Manager = new DataTable();
                    sqlQuery = $"select m.manager_name from manager m left join team t on m.manager_id = t.manager_id where t.team_id = '{cbox_home.SelectedValue}';";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(Manager);
                    lb_managerHome.Text = Manager.Rows[0][0].ToString();

                    dtCaptain = new DataTable();
                    sqlQuery = $"select p.player_name from team t left join player p on t.captain_id = p.player_id where t.team_id = '{cbox_home.SelectedValue}';";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtCaptain);
                    lb_captainHome.Text = dtCaptain.Rows[0][0].ToString();

                    DataTable dtStadium = new DataTable();
                    sqlQuery = $"select t.home_stadium from team t where t.team_id = '{cbox_home.SelectedValue}';";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtStadium);
                    lb_stadium.Text = dtStadium.Rows[0][0].ToString();

                    DataTable dtCapacity = new DataTable();
                    sqlQuery = $"select t.capacity from team t where t.team_id = '{cbox_home.SelectedValue}';";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtCapacity);
                    lb_capacity.Text = dtCapacity.Rows[0][0].ToString();
                }
            }
        }

        private void btn_check_Click(object sender, EventArgs e)
        {
             //sqlConnect = new MySqlConnection("server = localhost; uid = student; pwd = isbmantap; database = premier_league;");
            //sqlQuery = "select * from team";
            //sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            //sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            

            bool yn = false;
            for(int i = 0; i <dtMatch.Rows.Count; i++)
            {
                if (dtMatch.Rows[i][2].ToString() == cbox_home.SelectedValue.ToString() && dtMatch.Rows[i][3].ToString() == cbox_away.SelectedValue.ToString())
                {
                    yn = true;
                    indexRow = i;
                    break;
                }
            }
            if(yn)
            {
                lb_date.Text = dtMatch.Rows[indexRow][1].ToString(); 
                lb_score.Text = dtMatch.Rows[indexRow][4].ToString() + "-" + dtMatch.Rows[indexRow][5].ToString();
                DataTable dt = new DataTable();
                dtDGV = new DataTable();
                dt.Columns.Add("Minute");
                dt.Columns.Add("Player Name 1");
                dt.Columns.Add("Type 1");
                dt.Columns.Add("Player Name 2");
                dt.Columns.Add("Type 2");

                sqlQuery4 = "select d.minute, p.player_name, d.type, d.team_id from dmatch d join player p on p.player_id = d.player_id order by 1";
                sqlCommand = new MySqlCommand(sqlQuery4, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtDGV = new DataTable();
                sqlDataAdapter.Fill(dtDGV);

                for(int i = 0; i < dtDGV.Rows.Count; i++)
                {
                    if (dtDGV.Rows[i][3].ToString() == cbox_home.SelectedValue.ToString())
                    {
                        dt.Rows.Add(dtDGV.Rows[i][0].ToString(), dtDGV.Rows[i][1].ToString(), dtDGV.Rows[i][2].ToString(), " ", " ");
                    }
                    if (dtDGV.Rows[i][3].ToString() == cbox_away.SelectedValue.ToString())
                    {
                        dt.Rows.Add(dtDGV.Rows[i][0].ToString(), " ", " ", dtDGV.Rows[i][1].ToString(), dtDGV.Rows[i][2].ToString());
                    }
                }
                dgv.DataSource = dt;
            }
            else if(yn == false)
            {
                MessageBox.Show("NO DATA");
            }

        }

        private void cbox_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbox_home.SelectedIndex == -1 || cbox_away.SelectedIndex == -1)
            {

            }
            else
            {
                if (cbox_home.SelectedIndex == cbox_away.SelectedIndex)
                {
                    MessageBox.Show("Same Team");
                }
                else
                {

                    DataTable ManagerAway = new DataTable();
                    sqlQuery = $"select m.manager_name from manager m left join team t on m.manager_id = t.manager_id where t.team_id = '{cbox_away.SelectedValue}';";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(ManagerAway);
                    lb_managerAway.Text = ManagerAway.Rows[0][0].ToString();

                    dtCaptain = new DataTable();
                    sqlQuery = $"select p.player_name from team t left join player p on t.captain_id = p.player_id where t.team_id = '{cbox_away.SelectedValue}';";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtCaptain);
                    lb_captainAway.Text = dtCaptain.Rows[0][0].ToString();

                   
                }
            }
        }
    }
}
